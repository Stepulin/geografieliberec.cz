Line
=====

Line Shapefile
---------------

* Line.dbf: attribute data. (k=3)
* Line.prj: ESRI projection file. 
* Line.shp: Line shapefile. (n=4)
* Line.shx: spatial index.

Used for testing.
