virginia
========

Virginia counties shapefile
---------------------------

* virginia.dbf: attribute data. (k=7)
* virginia.gal: rook contiguity weights in GAL format.
* virginia.json: attribute and shape data in JSON format.
* virginia.prj: ESRI projection file.
* virginia.shp: Polygon shapefile. (n=136)
* virginia.shx: spatial index.
* virginia_queen.dat: queen contiguity weights in DAT format.
* virginia_queen.dbf: queen contiguity weights in DBF format.
* virginia_queen.gal: queen contiguity weights in GAL format.
* virginia_queen.mat: queen contiguity weights in MATLAB MAT format.
* virginia_queen.mtx: queen contiguity weights in Matrix Market MTX format.
* virginia_queen.swm: queen contiguity weight in ArcGIS SWM format.
* virginia_queen.txt: queen contiguity weights in TXT format.
* virginia_queen.wk1: queen contiguity weights in Lotus Wk1 format.
* virginia_rook.gal: rook contiguity weights in GAL format.
