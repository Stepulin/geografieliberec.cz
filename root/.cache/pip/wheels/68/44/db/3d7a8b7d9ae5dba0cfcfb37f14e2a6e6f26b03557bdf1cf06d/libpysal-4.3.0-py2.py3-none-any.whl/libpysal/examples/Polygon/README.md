Polygon
=======

Polygon Shapefile
-----------------

* Polygon.dbf: attribute data. (k=3)
* Polygon.prj: ESRI projection file.
* Polygon.shp: Polygon shapefile. (n=3)
* Polygon.shx: spatial index.

Used for testing.
