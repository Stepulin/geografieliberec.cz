Berlin
========

Prenzlauer Berg neighborhood AirBnB data from Berlin
-----------------------------------------------------

* prenzlauer.zip: attribute and goemetry data for rental point data (n=2203, k=9)
* prenz_bound.zip: Polygon of Prenzlauer Berg boundary

Data used in Oshan, Taylor, Ziqi Li, Wei Kang, Levi J. Wolf, and Alexander S.
Fotheringham. 2018. “Mgwr: A Python Implementation of Multiscale Geographically
Weighted Regression for Investigating Process Spatial Heterogeneity and Scale.”
OSF Preprints. October 2. doi:10.31219/osf.io/bphw9.
