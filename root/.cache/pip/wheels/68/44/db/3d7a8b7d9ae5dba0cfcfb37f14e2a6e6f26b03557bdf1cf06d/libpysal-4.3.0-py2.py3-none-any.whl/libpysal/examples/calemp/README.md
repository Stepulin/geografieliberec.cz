calemp
======

Employment density for California counties
------------------------------------------

* calempdensity.csv: data on employment and employment density in California
  counties. (n=58, k=11)

Source: Anselin, L. and S.J. Rey (in progress) Spatial Econometrics: Foundations.



