juvenile
========

Residences of juvenile offenders in Cardiff, UK
-----------------------------------------------

* juvenile.dbf: attribute data. (k=3)
* juvenile.gwt: spatial weights in GWT format.
* juvenile.shp: Point shapefile. (n=168)
* juvenile.shx: spatial index.

Source: Bailey, T. and A. Gatrell (1995). Interactive Spatial Data Analysis. New York: Wiley, p. 95.
Updated URL: https://geodacenter.github.io/data-and-lab/juvenile/
