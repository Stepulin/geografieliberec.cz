from . import fileio
from .tables import *
from .iohandlers import *
from .util import *
open = fileio.FileIO
