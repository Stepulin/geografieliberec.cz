burkitt
=======

Burkitt's lymphoma in the Western Nile district of Uganda
---------------------------------------------------------

* burkitt.dbf: attribute data. (k=6)
* burkitt.shp: Point shapefile. (n=188)
* burkitt.shx: spatial index.

Source: Williams, E. H., Smith, P. G., Day, N. E., Geser, A., Ellice, J., & Tukei, P. (1978). Space-time clustering of Burkitt's lymphoma in the West Nile district of Uganda: 1961-1975. British journal of cancer, 37(1), 109–122. https://doi.org/10.1038/bjc.1978.16