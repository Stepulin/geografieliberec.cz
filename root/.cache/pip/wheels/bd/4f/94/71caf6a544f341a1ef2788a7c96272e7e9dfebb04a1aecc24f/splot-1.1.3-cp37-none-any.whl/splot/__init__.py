__version__ = "1.1.3"
# __version__ has to be defined in the first line


#import modules/functions